from datetime import date
from decimal import Decimal

from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models
from django.utils import timezone

from clientes.models import Cliente
from contratos.models import Contrato
from inventario.models import Insumo


class MovimientoFinancieroMixin(models.Model):
    ESTADO_PENDIENTE = "pendiente"
    ESTADO_PARCIAL = "parcial"
    ESTADO_PAGADO = "pagado"
    ESTADO_VENCIDO = "vencido"
    ESTADO_ANULADO = "anulado"

    ESTADO_CHOICES = [
        (ESTADO_PENDIENTE, "Pendiente"),
        (ESTADO_PARCIAL, "Parcial"),
        (ESTADO_PAGADO, "Pagado"),
        (ESTADO_VENCIDO, "Vencido"),
        (ESTADO_ANULADO, "Anulado"),
    ]

    METODO_CHOICES = [
        ("efectivo", "Efectivo"),
        ("transferencia", "Transferencia"),
        ("tarjeta", "Tarjeta"),
        ("deposito", "Depósito"),
        ("cheque", "Cheque"),
        ("otro", "Otro"),
    ]

    estado = models.CharField(
        max_length=12,
        choices=ESTADO_CHOICES,
        default=ESTADO_PAGADO,
        db_index=True,
    )
    monto_pagado = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00"))],
    )
    fecha_vencimiento = models.DateField(null=True, blank=True, db_index=True)
    metodo_pago = models.CharField(max_length=20, choices=METODO_CHOICES, blank=True, default="")
    comprobante = models.FileField(upload_to="finanzas/comprobantes/%Y/%m/", null=True, blank=True)
    observaciones = models.TextField(blank=True, default="")
    creado_por = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="%(class)s_creados",
    )
    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True

    @property
    def saldo(self):
        if self.estado == self.ESTADO_ANULADO:
            return Decimal("0.00")
        return max((self.total or Decimal("0.00")) - (self.monto_pagado or Decimal("0.00")), Decimal("0.00"))

    @property
    def porcentaje_pagado(self):
        total = self.total or Decimal("0.00")
        if total <= 0:
            return 0
        return min(100, int(((self.monto_pagado or Decimal("0.00")) / total) * 100))

    @property
    def estado_visual(self):
        if (
            self.estado in {self.ESTADO_PENDIENTE, self.ESTADO_PARCIAL}
            and self.fecha_vencimiento
            and self.fecha_vencimiento < timezone.localdate()
        ):
            return self.ESTADO_VENCIDO
        return self.estado

    def _normalizar_estado_pago(self):
        total = self.total or Decimal("0.00")
        pagado = self.monto_pagado or Decimal("0.00")
        pagado = max(Decimal("0.00"), min(pagado, total))
        self.monto_pagado = pagado

        if self.estado == self.ESTADO_ANULADO:
            return
        if total > 0 and pagado >= total:
            self.estado = self.ESTADO_PAGADO
        elif pagado > 0:
            self.estado = self.ESTADO_PARCIAL
        elif self.fecha_vencimiento and self.fecha_vencimiento < timezone.localdate():
            self.estado = self.ESTADO_VENCIDO
        else:
            self.estado = self.ESTADO_PENDIENTE


class Egreso(MovimientoFinancieroMixin):
    CATEGORIA_CHOICES = [
        ("quimicos", "Químicos"),
        ("tecnicos", "Sueldos y pagos a técnicos"),
        ("transporte", "Transporte"),
        ("alimentacion", "Alimentación"),
        ("hospedaje", "Hospedaje"),
        ("materiales", "Materiales"),
        ("herramientas", "Herramientas"),
        ("reparaciones", "Reparaciones"),
        ("publicidad", "Publicidad"),
        ("servicios", "Servicios"),
        ("administracion", "Administración"),
        ("otros", "Otros gastos"),
    ]

    mantenimiento = models.ForeignKey(
        "mantenimientos.Mantenimiento",
        on_delete=models.CASCADE,
        related_name="egresos",
        null=True,
        blank=True,
    )
    insumo = models.ForeignKey(Insumo, on_delete=models.PROTECT, null=True, blank=True)
    concepto = models.CharField(max_length=120, blank=True, default="")
    categoria = models.CharField(max_length=30, choices=CATEGORIA_CHOICES, blank=True, default="otros", db_index=True)
    cantidad = models.PositiveIntegerField(default=1)
    costo_unitario = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(Decimal("0.00"))])
    total = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    fecha = models.DateField(default=date.today, db_index=True)
    proveedor = models.CharField(max_length=150, blank=True, default="")
    ciudad_proyecto = models.CharField(max_length=120, blank=True, default="")
    aprobado = models.BooleanField(default=True, db_index=True)

    @property
    def es_manual(self):
        return not self.mantenimiento_id and not self.insumo_id

    def save(self, *args, **kwargs):
        self.total = (self.cantidad or 0) * (self.costo_unitario or Decimal("0.00"))
        if self._state.adding and self.estado == self.ESTADO_PAGADO and not self.monto_pagado:
            self.monto_pagado = self.total
        self._normalizar_estado_pago()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.concepto or (self.insumo.nombre if self.insumo else 'Egreso')} - {self.total}"

    class Meta:
        verbose_name = "Egreso"
        verbose_name_plural = "Egresos"
        ordering = ["-fecha", "-id"]


class Ingreso(MovimientoFinancieroMixin):
    cliente = models.ForeignKey(Cliente, on_delete=models.PROTECT, null=True, blank=True, related_name="ingresos")
    contrato = models.ForeignKey(Contrato, on_delete=models.PROTECT, null=True, blank=True, related_name="ingresos")
    concepto = models.CharField(max_length=120)
    total = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    fecha = models.DateField(default=date.today, db_index=True)
    fecha_cobro = models.DateField(null=True, blank=True)
    ciudad = models.CharField(max_length=120, blank=True, default="")

    def save(self, *args, **kwargs):
        if self._state.adding and self.estado == self.ESTADO_PAGADO and not self.monto_pagado:
            self.monto_pagado = self.total
        self._normalizar_estado_pago()
        if self.estado == self.ESTADO_PAGADO and not self.fecha_cobro:
            self.fecha_cobro = self.fecha
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.fecha} - {self.concepto} - {self.total}"

    class Meta:
        verbose_name = "Ingreso"
        verbose_name_plural = "Ingresos"
        ordering = ["-fecha", "-id"]


class MovimientoRecurrente(models.Model):
    TIPO_CHOICES = [("ingreso", "Ingreso"), ("egreso", "Egreso")]
    FRECUENCIA_CHOICES = [("mensual", "Mensual"), ("semanal", "Semanal")]

    tipo = models.CharField(max_length=10, choices=TIPO_CHOICES)
    concepto = models.CharField(max_length=120)
    monto = models.DecimalField(max_digits=12, decimal_places=2)
    frecuencia = models.CharField(max_length=10, choices=FRECUENCIA_CHOICES, default="mensual")
    proxima_fecha = models.DateField()
    activo = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.tipo.upper()} - {self.concepto} - {self.monto}"

    class Meta:
        verbose_name = "Movimiento recurrente"
        verbose_name_plural = "Movimientos recurrentes"



class PromocionContrato(models.Model):
    TIPO_PORCENTAJE = "porcentaje"
    TIPO_VALOR_FIJO = "valor_fijo"
    TIPO_GRATIS = "gratis"
    TIPO_VALOR_ESPECIAL = "valor_especial"
    TIPO_CHOICES = [
        (TIPO_PORCENTAJE, "Porcentaje de descuento"),
        (TIPO_VALOR_FIJO, "Valor fijo de descuento"),
        (TIPO_GRATIS, "Mes gratis / 100%"),
        (TIPO_VALOR_ESPECIAL, "Valor especial a cobrar"),
    ]

    contrato = models.ForeignKey(Contrato, on_delete=models.CASCADE, related_name="promociones")
    nombre = models.CharField(max_length=120)
    motivo = models.TextField()
    tipo = models.CharField(max_length=20, choices=TIPO_CHOICES)
    valor = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    anio_inicio = models.PositiveIntegerField()
    mes_inicio = models.PositiveSmallIntegerField()
    anio_fin = models.PositiveIntegerField()
    mes_fin = models.PositiveSmallIntegerField()
    activa = models.BooleanField(default=True)
    creado_por = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="promociones_contrato_creadas")
    creada_en = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-anio_inicio", "-mes_inicio", "-id"]

    def __str__(self):
        return f"{self.contrato} · {self.nombre}"

    @property
    def periodo_inicio_clave(self):
        return self.anio_inicio * 100 + self.mes_inicio

    @property
    def periodo_fin_clave(self):
        return self.anio_fin * 100 + self.mes_fin

    def aplica_a(self, anio, mes):
        clave = int(anio) * 100 + int(mes)
        return self.activa and self.periodo_inicio_clave <= clave <= self.periodo_fin_clave

    def calcular(self, valor_contractual):
        base = max(Decimal(valor_contractual or 0), Decimal("0.00"))
        if self.tipo == self.TIPO_GRATIS:
            total = Decimal("0.00")
        elif self.tipo == self.TIPO_PORCENTAJE:
            pct = min(max(self.valor, Decimal("0.00")), Decimal("100.00"))
            total = base * (Decimal("1.00") - pct / Decimal("100.00"))
        elif self.tipo == self.TIPO_VALOR_FIJO:
            total = max(base - self.valor, Decimal("0.00"))
        else:
            total = min(max(self.valor, Decimal("0.00")), base)
        total = total.quantize(Decimal("0.01"))
        return {"valor_contractual": base.quantize(Decimal("0.01")), "descuento": (base-total).quantize(Decimal("0.01")), "total": total}


class Factura(models.Model):
    ESTADO_PENDIENTE = "pendiente"
    ESTADO_PARCIAL = "parcial"
    ESTADO_PAGADA = "pagada"
    ESTADO_VENCIDA = "vencida"
    ESTADO_ANULADA = "anulada"
    ESTADO_PROMOCION = "promocion"
    ESTADO_CHOICES = [
        (ESTADO_PENDIENTE, "Pendiente"),
        (ESTADO_PARCIAL, "Parcial"),
        (ESTADO_PAGADA, "Pagada"),
        (ESTADO_VENCIDA, "Vencida"),
        (ESTADO_ANULADA, "Anulada"),
        (ESTADO_PROMOCION, "Cubierto por promoción"),
    ]

    cliente = models.ForeignKey(Cliente, on_delete=models.PROTECT, related_name="facturas")
    contrato = models.ForeignKey(Contrato, on_delete=models.PROTECT, related_name="facturas")
    numero = models.CharField(max_length=30, unique=True, blank=True)
    periodo_anio = models.PositiveIntegerField()
    periodo_mes = models.PositiveIntegerField()
    periodo_inicio = models.DateField(null=True, blank=True)
    periodo_fin = models.DateField(null=True, blank=True)
    cuota_numero = models.PositiveSmallIntegerField(default=1)
    total_cuotas = models.PositiveSmallIntegerField(default=1)
    fecha_emision = models.DateField(default=date.today)
    fecha_cobro_desde = models.DateField(null=True, blank=True)
    fecha_vencimiento = models.DateField()
    fecha_facturacion_programada = models.DateField(null=True, blank=True)
    requiere_factura = models.BooleanField(default=False)
    factura_enviada = models.BooleanField(default=False)
    factura_enviada_en = models.DateField(null=True, blank=True)
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    impuesto = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    valor_contractual = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    descuento_promocion = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    promocion = models.ForeignKey("PromocionContrato", on_delete=models.SET_NULL, null=True, blank=True, related_name="facturas")
    promocion_nombre = models.CharField(max_length=120, blank=True, default="")
    estado = models.CharField(max_length=10, choices=ESTADO_CHOICES, default=ESTADO_PENDIENTE)
    observaciones = models.TextField(blank=True, default="")
    ingreso_generado = models.OneToOneField(
        Ingreso, on_delete=models.SET_NULL, null=True, blank=True, related_name="factura_origen"
    )
    pagada_en = models.DateField(null=True, blank=True)
    creada_en = models.DateTimeField(auto_now_add=True)
    actualizada_en = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Factura"
        verbose_name_plural = "Facturas"
        ordering = ["-periodo_anio", "-periodo_mes", "-id"]
        constraints = [
            models.UniqueConstraint(
                fields=["contrato", "periodo_anio", "periodo_mes", "cuota_numero"],
                name="unique_factura_cuota_por_contrato_periodo",
            )
        ]

    def __str__(self):
        return f"{self.numero or 'Factura'} - {self.cliente} - {self.periodo_mes:02d}/{self.periodo_anio}"

    @property
    def periodo_label(self):
        etiqueta = f"{self.periodo_mes:02d}/{self.periodo_anio}"
        if self.total_cuotas and self.total_cuotas > 1:
            etiqueta += f" · cuota {self.cuota_numero}/{self.total_cuotas}"
        return etiqueta

    @property
    def esta_vencida(self):
        return self.estado in {self.ESTADO_PENDIENTE, self.ESTADO_PARCIAL} and self.fecha_vencimiento < timezone.localdate()

    @property
    def monto_pagado(self):
        """Total cobrado sin provocar N+1 cuando ``pagos`` está prefetched."""
        cache = getattr(self, "_prefetched_objects_cache", {})
        pagos_prefetched = cache.get("pagos")
        if pagos_prefetched is not None:
            total_pagos = sum(
                (p.monto for p in pagos_prefetched if p.activo),
                Decimal("0.00"),
            )
        else:
            total_pagos = self.pagos.filter(activo=True).aggregate(
                valor=models.Sum("monto")
            )["valor"] or Decimal("0.00")
        if total_pagos == 0 and self.ingreso_generado_id and self.estado == self.ESTADO_PAGADA:
            return self.total or Decimal("0.00")
        return total_pagos

    @property
    def total_cobro(self):
        """Total realmente exigible después de promociones o descuentos.

        Se calcula también en lectura para corregir cuentas antiguas que pudieron
        conservar el total contractual aunque ya tuvieran una promoción aplicada.
        """
        descuento = self.descuento_promocion or Decimal("0.00")
        if self.promocion_id or descuento > 0:
            contractual = self.valor_contractual or self.subtotal or self.total or Decimal("0.00")
            neto = max(contractual - descuento, Decimal("0.00"))
            return (neto + (self.impuesto or Decimal("0.00"))).quantize(Decimal("0.01"))
        return (self.total or Decimal("0.00")).quantize(Decimal("0.01"))

    @property
    def saldo(self):
        if self.estado in {self.ESTADO_ANULADA, self.ESTADO_PROMOCION}:
            return Decimal("0.00")
        return max(self.total_cobro - self.monto_pagado, Decimal("0.00"))

    @property
    def porcentaje_pagado(self):
        total_cobro = self.total_cobro
        if not total_cobro:
            return 100 if self.estado == self.ESTADO_PROMOCION else 0
        return min(100, int((self.monto_pagado / total_cobro) * 100))

    @property
    def fecha_real_cobro(self):
        """Fecha desde la que la cuenta pertenece realmente a Cartera.

        ``periodo_anio/periodo_mes`` identifican el ciclo de servicio, no
        necesariamente el mes calendario de cobro. Esta propiedad evita usar
        esas claves contables como si fueran una fecha de vencimiento.
        """
        return self.fecha_cobro_desde or self.fecha_vencimiento

    @property
    def periodo_servicio_label(self):
        if self.periodo_inicio and self.periodo_fin:
            etiqueta = f"{self.periodo_inicio:%d/%m/%Y} → {self.periodo_fin:%d/%m/%Y}"
            if self.total_cuotas and self.total_cuotas > 1:
                etiqueta += f" · cuota {self.cuota_numero}/{self.total_cuotas}"
            return etiqueta
        return self.periodo_label

    @property
    def es_programada_futura(self):
        if self.estado in {self.ESTADO_PAGADA, self.ESTADO_ANULADA, self.ESTADO_PROMOCION}:
            return False
        return bool(
            self.saldo > 0
            and self.fecha_real_cobro
            and self.fecha_real_cobro > timezone.localdate()
        )

    @property
    def estado_gestion(self):
        """Estado para gestión de cartera, separando deuda de programación futura."""
        if self.es_programada_futura:
            return "programada"
        return self.estado_visual

    @property
    def estado_gestion_label(self):
        if self.estado_gestion == "programada":
            return "Programada"
        if self.estado_visual == self.ESTADO_VENCIDA:
            return "Vencida"
        return self.get_estado_display()

    @property
    def estado_visual(self):
        if self.estado not in {self.ESTADO_PAGADA, self.ESTADO_ANULADA} and self.fecha_vencimiento < timezone.localdate():
            return self.ESTADO_VENCIDA
        return self.estado

    def sincronizar_estado(self, guardar=True):
        if self.estado in {self.ESTADO_ANULADA, self.ESTADO_PROMOCION}:
            return self.estado
        pagado = self.monto_pagado
        total_cobro = self.total_cobro
        if total_cobro > 0 and pagado >= total_cobro:
            nuevo = self.ESTADO_PAGADA
        elif pagado > 0:
            nuevo = self.ESTADO_PARCIAL
        elif self.fecha_vencimiento < timezone.localdate():
            nuevo = self.ESTADO_VENCIDA
        else:
            nuevo = self.ESTADO_PENDIENTE
        self.estado = nuevo
        self.pagada_en = timezone.localdate() if nuevo == self.ESTADO_PAGADA and not self.pagada_en else (None if nuevo != self.ESTADO_PAGADA else self.pagada_en)
        if guardar:
            self.save(update_fields=["estado", "pagada_en", "actualizada_en"])
        return nuevo

    def actualizar_totales(self, guardar=True):
        subtotal = sum((item.subtotal for item in self.items.all()), Decimal("0"))
        self.subtotal = subtotal
        descuento = self.descuento_promocion or Decimal("0.00")
        if self.promocion_id or descuento > 0:
            contractual = self.valor_contractual or subtotal
            self.total = max(contractual - descuento, Decimal("0.00")) + (self.impuesto or Decimal("0"))
        else:
            self.total = subtotal + (self.impuesto or Decimal("0"))
        if guardar:
            self.save(update_fields=["subtotal", "total", "actualizada_en"])

    def marcar_como_pagada(self, fecha_pago=None):
        """Compatibilidad: registra un pago por el saldo completo."""
        if self.estado == self.ESTADO_PAGADA or self.saldo <= 0:
            return self.ingreso_generado
        pago = PagoFactura.objects.create(
            factura=self,
            monto=self.saldo,
            fecha=fecha_pago or timezone.localdate(),
            metodo_pago="otro",
            observaciones="Pago total registrado desde compatibilidad anterior.",
        )
        return pago.ingreso

    def marcar_como_vencida_si_aplica(self, guardar=True):
        if self.esta_vencida:
            self.estado = self.ESTADO_VENCIDA
            if guardar:
                self.save(update_fields=["estado", "actualizada_en"])

    def save(self, *args, **kwargs):
        es_nueva = self.pk is None
        if self.numero is None:
            self.numero = ""
        descuento = self.descuento_promocion or Decimal("0.00")
        if self.promocion_id or descuento > 0:
            contractual = self.valor_contractual or self.subtotal or Decimal("0.00")
            self.total = max(contractual - descuento, Decimal("0.00")) + (self.impuesto or Decimal("0"))
        else:
            self.total = (self.subtotal or Decimal("0")) + (self.impuesto or Decimal("0"))
        if self.estado == self.ESTADO_PENDIENTE and self.fecha_vencimiento < timezone.localdate():
            self.estado = self.ESTADO_VENCIDA
        super().save(*args, **kwargs)
        numero_esperado = f"FAC-{self.periodo_anio}{self.periodo_mes:02d}-C{self.cuota_numero}-{self.pk:05d}"
        if self.numero != numero_esperado:
            self.numero = numero_esperado
            super().save(update_fields=["numero", "actualizada_en"] if not es_nueva else ["numero"])



class AvisoFacturacion(models.Model):
    ESTADO_PENDIENTE = "pendiente"
    ESTADO_REALIZADA = "realizada"
    ESTADO_ANULADA = "anulada"
    ESTADO_CHOICES = [
        (ESTADO_PENDIENTE, "Pendiente"),
        (ESTADO_REALIZADA, "Factura realizada"),
        (ESTADO_ANULADA, "Anulada"),
    ]

    contrato = models.ForeignKey(
        Contrato,
        on_delete=models.CASCADE,
        related_name="avisos_facturacion",
    )
    periodo_anio = models.PositiveIntegerField()
    periodo_mes = models.PositiveSmallIntegerField()
    cuota_numero = models.PositiveSmallIntegerField(
        default=1,
        help_text="Número de cuota/visita dentro del período. En pago por visita permite varios avisos mensuales.",
    )
    periodo_inicio = models.DateField()
    periodo_fin = models.DateField()
    fecha_programada = models.DateField(db_index=True)
    estado = models.CharField(
        max_length=12,
        choices=ESTADO_CHOICES,
        default=ESTADO_PENDIENTE,
        db_index=True,
    )
    realizada_en = models.DateTimeField(null=True, blank=True)
    realizada_por = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="facturas_externas_realizadas",
    )
    creada_en = models.DateTimeField(auto_now_add=True)
    actualizada_en = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["fecha_programada", "contrato__cliente__nombre", "id"]
        constraints = [
            models.UniqueConstraint(
                fields=["contrato", "periodo_anio", "periodo_mes", "cuota_numero"],
                name="unique_aviso_facturacion_cuota_periodo",
            )
        ]
        verbose_name = "Aviso de facturación"
        verbose_name_plural = "Avisos de facturación"

    @property
    def cliente(self):
        return self.contrato.cliente

    @property
    def es_por_visita(self):
        return (
            self.contrato.forma_pago == "por_visita"
            or self.contrato.programacion_cobro == "por_visita"
            or self.contrato.momento_facturacion == "por_visita"
        )

    @property
    def periodo_label(self):
        if self.es_por_visita:
            return f"Visita #{self.cuota_numero} · {self.fecha_programada:%d/%m/%Y}"
        return f"{self.periodo_inicio:%d/%m/%Y} → {self.periodo_fin:%d/%m/%Y}"

    @property
    def fecha_alerta(self):
        dias = int(self.contrato.notificacion_factura_dias_antes or 0)
        from datetime import timedelta
        return self.fecha_programada - timedelta(days=dias)

    @property
    def esta_atrasada(self):
        return self.estado == self.ESTADO_PENDIENTE and self.fecha_programada < timezone.localdate()

    def marcar_realizada(self, usuario=None):
        self.estado = self.ESTADO_REALIZADA
        self.realizada_en = timezone.now()
        self.realizada_por = usuario
        self.save(update_fields=["estado", "realizada_en", "realizada_por", "actualizada_en"])

    def __str__(self):
        if self.es_por_visita:
            return f"{self.contrato.cliente} · visita #{self.cuota_numero} · {self.fecha_programada:%d/%m/%Y}"
        return f"{self.contrato.cliente} · {self.periodo_mes:02d}/{self.periodo_anio}"


class FacturaItem(models.Model):
    factura = models.ForeignKey(Factura, on_delete=models.CASCADE, related_name="items")
    descripcion = models.CharField(max_length=180)
    cantidad = models.DecimalField(max_digits=10, decimal_places=2, default=1)
    precio_unitario = models.DecimalField(max_digits=12, decimal_places=2)
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    def save(self, *args, **kwargs):
        self.subtotal = (self.cantidad or Decimal("0")) * (self.precio_unitario or Decimal("0"))
        super().save(*args, **kwargs)
        self.factura.actualizar_totales()

    def delete(self, *args, **kwargs):
        factura = self.factura
        super().delete(*args, **kwargs)
        factura.actualizar_totales()

    def __str__(self):
        return self.descripcion


class PagoFactura(models.Model):
    factura = models.ForeignKey(Factura, on_delete=models.PROTECT, related_name="pagos")
    monto = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    fecha = models.DateField(default=date.today, db_index=True)
    metodo_pago = models.CharField(max_length=20, choices=MovimientoFinancieroMixin.METODO_CHOICES, default="transferencia")
    referencia = models.CharField(max_length=120, blank=True, default="")
    comprobante = models.FileField(upload_to="finanzas/pagos_facturas/%Y/%m/", null=True, blank=True)
    observaciones = models.TextField(blank=True, default="")
    ingreso = models.OneToOneField(Ingreso, on_delete=models.SET_NULL, null=True, blank=True, related_name="pago_factura")
    activo = models.BooleanField(default=True, db_index=True)
    creado_por = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="pagos_factura_creados")
    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Pago de factura"
        verbose_name_plural = "Pagos de facturas"
        ordering = ["-fecha", "-id"]

    def __str__(self):
        return f"{self.factura.numero} - {self.monto}"

    def save(self, *args, **kwargs):
        creando = self._state.adding
        if self.factura_id and self.activo:
            saldo_disponible = self.factura.saldo
            if not creando:
                anterior = PagoFactura.objects.filter(pk=self.pk).values("monto", "activo").first()
                if anterior and anterior["activo"]:
                    saldo_disponible += anterior["monto"]
            if self.monto > saldo_disponible:
                from django.core.exceptions import ValidationError
                raise ValidationError({"monto": f"El pago no puede superar el saldo pendiente de ${saldo_disponible:.2f}."})
        super().save(*args, **kwargs)

        if self.activo:
            ingreso = self.ingreso
            datos = {
                "cliente": self.factura.cliente,
                "contrato": self.factura.contrato,
                "concepto": f"Cobro {self.factura.numero} - {self.factura.periodo_label}",
                "total": self.monto,
                "monto_pagado": self.monto,
                "estado": Ingreso.ESTADO_PAGADO,
                "fecha": self.fecha,
                "fecha_cobro": self.fecha,
                "metodo_pago": self.metodo_pago,
                "comprobante": self.comprobante,
                "observaciones": self.observaciones,
                "creado_por": self.creado_por,
            }
            if ingreso:
                for campo, valor in datos.items():
                    setattr(ingreso, campo, valor)
                ingreso.save()
            else:
                self.ingreso = Ingreso.objects.create(**datos)
                super().save(update_fields=["ingreso", "actualizado_en"])
        elif self.ingreso_id and self.ingreso.estado != Ingreso.ESTADO_ANULADO:
            self.ingreso.estado = Ingreso.ESTADO_ANULADO
            self.ingreso.monto_pagado = Decimal("0.00")
            self.ingreso.save(update_fields=["estado", "monto_pagado", "actualizado_en"])

        self.factura.sincronizar_estado()

    def anular(self):
        if not self.activo:
            return
        self.activo = False
        self.save(update_fields=["activo", "actualizado_en"])


class AnticipoTrabajador(models.Model):
    trabajador = models.ForeignKey("trabajadores.Trabajador", on_delete=models.PROTECT, related_name="anticipos")
    monto = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    fecha = models.DateField(default=date.today, db_index=True)
    periodo_anio = models.PositiveIntegerField(db_index=True)
    periodo_mes = models.PositiveIntegerField(db_index=True)
    descontado = models.BooleanField(default=False, db_index=True)
    monto_descontado = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    fecha_descuento = models.DateField(null=True, blank=True)
    observaciones = models.TextField(blank=True, default="")
    egreso = models.OneToOneField(Egreso, on_delete=models.SET_NULL, null=True, blank=True, related_name="anticipo_trabajador")
    creado_por = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="anticipos_trabajador_creados")
    creado_en = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-fecha", "-id"]
        verbose_name = "Anticipo a trabajador"
        verbose_name_plural = "Anticipos a trabajadores"

    def __str__(self):
        return f"Anticipo {self.trabajador} - ${self.monto}"

    @property
    def periodo_label(self):
        return f"{self.periodo_mes:02d}/{self.periodo_anio}"

    @property
    def saldo_pendiente(self):
        return max(self.monto - self.monto_descontado, Decimal("0.00"))

    def crear_egreso(self):
        if self.egreso_id:
            return
        self.egreso = Egreso.objects.create(
            concepto=f"Anticipo a {self.trabajador} - {self.periodo_label}",
            categoria="tecnicos", cantidad=1, costo_unitario=self.monto, total=self.monto,
            monto_pagado=self.monto, estado=Egreso.ESTADO_PAGADO, fecha=self.fecha,
            metodo_pago="transferencia", proveedor=str(self.trabajador),
            observaciones=self.observaciones, creado_por=self.creado_por,
        )
        self.save(update_fields=["egreso"])


class ObligacionTrabajador(models.Model):
    ESTADO_PENDIENTE = "pendiente"
    ESTADO_PARCIAL = "parcial"
    ESTADO_PAGADO = "pagado"
    ESTADO_ANULADO = "anulado"
    ESTADO_CHOICES = [
        (ESTADO_PENDIENTE, "Pendiente"),
        (ESTADO_PARCIAL, "Parcial"),
        (ESTADO_PAGADO, "Pagado"),
        (ESTADO_ANULADO, "Anulado"),
    ]

    trabajador = models.ForeignKey("trabajadores.Trabajador", on_delete=models.PROTECT, related_name="obligaciones_pago")
    contrato = models.ForeignKey(
        Contrato,
        on_delete=models.PROTECT,
        related_name="obligaciones_trabajador",
        null=True,
        blank=True,
        help_text="Vacío cuando la obligación corresponde a una mensualidad fija del trabajador.",
    )
    periodo_anio = models.PositiveIntegerField(db_index=True)
    periodo_mes = models.PositiveIntegerField(db_index=True)
    valor_acordado = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    periodo_servicio_inicio = models.DateField(
        null=True,
        blank=True,
        db_index=True,
        help_text="Fecha inicial del servicio que origina esta obligación. Se conserva históricamente.",
    )
    periodo_servicio_fin = models.DateField(
        null=True,
        blank=True,
        db_index=True,
        help_text="Fecha final del servicio que origina esta obligación. Se conserva históricamente.",
    )
    fecha_pago_programada = models.DateField(
        db_index=True,
        help_text="Fecha prevista para pagar al trabajador; coincide con la fecha de cobro del contrato en este periodo.",
    )
    estado = models.CharField(max_length=12, choices=ESTADO_CHOICES, default=ESTADO_PENDIENTE, db_index=True)
    observaciones = models.TextField(blank=True, default="")
    creada_en = models.DateTimeField(auto_now_add=True)
    actualizada_en = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-periodo_anio", "-periodo_mes", "trabajador__user__username", "id"]
        constraints = [
            models.UniqueConstraint(
                fields=["contrato", "periodo_anio", "periodo_mes"],
                name="unique_obligacion_trabajador_periodo",
            ),
            models.UniqueConstraint(
                fields=["trabajador", "periodo_anio", "periodo_mes"],
                condition=models.Q(contrato__isnull=True),
                name="unique_nomina_fija_trabajador_periodo",
            ),
        ]
        verbose_name = "Obligación de pago a trabajador"
        verbose_name_plural = "Obligaciones de pago a trabajadores"

    def __str__(self):
        if self.contrato_id:
            return f"{self.trabajador} - {self.contrato.cliente} - {self.periodo_mes:02d}/{self.periodo_anio}"
        return f"{self.trabajador} - Mensualidad fija - {self.periodo_mes:02d}/{self.periodo_anio}"

    @property
    def es_nomina_fija(self):
        return self.contrato_id is None

    @property
    def concepto_origen(self):
        if self.contrato_id:
            return str(self.contrato.cliente)
        return "Mensualidad fija"

    @property
    def periodo_label(self):
        return f"{self.periodo_mes:02d}/{self.periodo_anio}"

    @property
    def periodo_servicio_label(self):
        if self.periodo_servicio_inicio and self.periodo_servicio_fin:
            return f"{self.periodo_servicio_inicio.strftime('%d/%m/%Y')} al {self.periodo_servicio_fin.strftime('%d/%m/%Y')}"
        return self.periodo_label

    @property
    def monto_pagado(self):
        return self.pagos.filter(activo=True).aggregate(total=models.Sum("monto"))["total"] or Decimal("0.00")

    @property
    def saldo(self):
        if self.estado == self.ESTADO_ANULADO:
            return Decimal("0.00")
        return max(self.valor_acordado - self.monto_pagado, Decimal("0.00"))

    def sincronizar_estado(self):
        if self.estado == self.ESTADO_ANULADO:
            return
        pagado = self.monto_pagado
        nuevo = self.ESTADO_PAGADO if pagado >= self.valor_acordado else self.ESTADO_PARCIAL if pagado > 0 else self.ESTADO_PENDIENTE
        if nuevo != self.estado:
            self.estado = nuevo
            self.save(update_fields=["estado", "actualizada_en"])


class LotePagoTrabajador(models.Model):
    trabajador = models.ForeignKey("trabajadores.Trabajador", on_delete=models.PROTECT, related_name="lotes_pago")
    periodo_anio = models.PositiveIntegerField(db_index=True)
    periodo_mes = models.PositiveIntegerField(db_index=True)
    monto = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    fecha = models.DateField(default=date.today, db_index=True)
    metodo_pago = models.CharField(max_length=20, choices=MovimientoFinancieroMixin.METODO_CHOICES, default="transferencia")
    referencia = models.CharField(max_length=120, blank=True, default="")
    comprobante = models.FileField(upload_to="finanzas/pagos_trabajadores_consolidados/%Y/%m/", null=True, blank=True)
    observaciones = models.TextField(blank=True, default="")
    egreso = models.OneToOneField(Egreso, on_delete=models.SET_NULL, null=True, blank=True, related_name="lote_pago_trabajador")
    activo = models.BooleanField(default=True, db_index=True)
    creado_por = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="lotes_pago_trabajador_creados")
    creado_en = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-fecha", "-id"]
        verbose_name = "Pago consolidado a trabajador"
        verbose_name_plural = "Pagos consolidados a trabajadores"

    def __str__(self):
        return f"{self.trabajador} - {self.periodo_mes:02d}/{self.periodo_anio} - ${self.monto}"

    @property
    def periodo_label(self):
        return f"{self.periodo_mes:02d}/{self.periodo_anio}"

    def crear_egreso(self):
        if self.egreso_id or not self.activo:
            return
        self.egreso = Egreso.objects.create(
            concepto=f"Pago consolidado a {self.trabajador} - {self.periodo_label}",
            categoria="tecnicos", cantidad=1, costo_unitario=self.monto, total=self.monto,
            monto_pagado=self.monto, estado=Egreso.ESTADO_PAGADO, fecha=self.fecha,
            metodo_pago=self.metodo_pago, proveedor=str(self.trabajador),
            comprobante=self.comprobante, observaciones=self.observaciones, creado_por=self.creado_por,
        )
        self.save(update_fields=["egreso"])


class PagoTrabajador(models.Model):
    lote = models.ForeignKey(LotePagoTrabajador, on_delete=models.PROTECT, related_name="distribuciones", null=True, blank=True)
    obligacion = models.ForeignKey(ObligacionTrabajador, on_delete=models.PROTECT, related_name="pagos")
    monto = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    fecha = models.DateField(default=date.today, db_index=True)
    metodo_pago = models.CharField(max_length=20, choices=MovimientoFinancieroMixin.METODO_CHOICES, default="transferencia")
    referencia = models.CharField(max_length=120, blank=True, default="")
    comprobante = models.FileField(upload_to="finanzas/pagos_trabajadores/%Y/%m/", null=True, blank=True)
    observaciones = models.TextField(blank=True, default="")
    egreso = models.OneToOneField(Egreso, on_delete=models.SET_NULL, null=True, blank=True, related_name="pago_trabajador")
    activo = models.BooleanField(default=True, db_index=True)
    creado_por = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="pagos_trabajador_creados")
    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-fecha", "-id"]
        verbose_name = "Pago a trabajador"
        verbose_name_plural = "Pagos a trabajadores"

    def __str__(self):
        return f"{self.obligacion.trabajador} - ${self.monto}"

    def save(self, *args, **kwargs):
        creando = self._state.adding
        if self.obligacion_id and self.activo:
            saldo = self.obligacion.saldo
            if not creando:
                anterior = PagoTrabajador.objects.filter(pk=self.pk).values("monto", "activo").first()
                if anterior and anterior["activo"]:
                    saldo += anterior["monto"]
            if self.monto > saldo:
                from django.core.exceptions import ValidationError
                raise ValidationError({"monto": f"El pago no puede superar el saldo pendiente de ${saldo:.2f}."})
        super().save(*args, **kwargs)
        if self.activo and not self.lote_id:
            if self.obligacion.contrato_id:
                origen = str(self.obligacion.contrato.cliente)
                ciudad = self.obligacion.contrato.cliente.ciudad or ""
            else:
                origen = "Mensualidad fija"
                ciudad = (
                    self.obligacion.trabajador.ciudad_principal.nombre
                    if self.obligacion.trabajador.ciudad_principal_id
                    else ""
                )
            datos = {
                "concepto": f"Pago a {self.obligacion.trabajador} - {self.obligacion.periodo_label} - {origen}",
                "categoria": "tecnicos", "cantidad": 1, "costo_unitario": self.monto,
                "total": self.monto, "monto_pagado": self.monto, "estado": Egreso.ESTADO_PAGADO,
                "fecha": self.fecha, "metodo_pago": self.metodo_pago,
                "proveedor": str(self.obligacion.trabajador),
                "ciudad_proyecto": ciudad,
                "comprobante": self.comprobante, "observaciones": self.observaciones,
                "creado_por": self.creado_por,
            }
            if self.egreso_id:
                for campo, valor in datos.items(): setattr(self.egreso, campo, valor)
                self.egreso.save()
            else:
                self.egreso = Egreso.objects.create(**datos)
                super().save(update_fields=["egreso", "actualizado_en"])
        elif self.egreso_id and self.egreso.estado != Egreso.ESTADO_ANULADO:
            self.egreso.estado = Egreso.ESTADO_ANULADO
            self.egreso.monto_pagado = Decimal("0.00")
            self.egreso.save(update_fields=["estado", "monto_pagado", "actualizado_en"])
        self.obligacion.sincronizar_estado()

    def anular(self):
        if self.activo:
            self.activo = False
            self.save(update_fields=["activo", "actualizado_en"])

class ComprobanteServicio(models.Model):
    ESTADO_EMITIDO = "EMITIDO"
    ESTADO_ANULADO = "ANULADO"
    ESTADOS = [(ESTADO_EMITIDO, "Emitido"), (ESTADO_ANULADO, "Anulado")]
    numero = models.PositiveIntegerField(unique=True, editable=False)
    fecha = models.DateField(default=timezone.localdate)
    cliente_nombre = models.CharField(max_length=180)
    cliente_identificacion = models.CharField(max_length=30, blank=True)
    cliente_direccion = models.CharField(max_length=255, blank=True)
    cliente_telefono = models.CharField(max_length=50, blank=True)
    cliente_email = models.EmailField(blank=True)
    forma_pago = models.CharField(max_length=120, blank=True)
    observaciones = models.TextField(blank=True)
    descuento = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    estado = models.CharField(max_length=12, choices=ESTADOS, default=ESTADO_EMITIDO)
    creado_por = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="comprobantes_servicio_creados")
    creado_en = models.DateTimeField(auto_now_add=True)
    anulado_en = models.DateTimeField(null=True, blank=True)
    class Meta: ordering = ["-fecha", "-numero"]
    def save(self, *args, **kwargs):
        if not self.numero:
            self.numero = (ComprobanteServicio.objects.order_by("-numero").values_list("numero", flat=True).first() or 0) + 1
        super().save(*args, **kwargs)
    @property
    def numero_formateado(self): return f"CS-{self.numero:06d}"
    @property
    def subtotal(self): return sum((d.total for d in self.detalles.all()), Decimal("0.00"))
    @property
    def total(self): return max(self.subtotal - (self.descuento or Decimal("0.00")), Decimal("0.00"))

class DetalleComprobanteServicio(models.Model):
    comprobante = models.ForeignKey(ComprobanteServicio, on_delete=models.CASCADE, related_name="detalles")
    cantidad = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("1.00"))
    descripcion = models.TextField()
    precio_unitario = models.DecimalField(max_digits=12, decimal_places=2)
    @property
    def total(self): return (self.cantidad * self.precio_unitario).quantize(Decimal("0.01"))
