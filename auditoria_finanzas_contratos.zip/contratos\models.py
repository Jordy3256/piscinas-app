from calendar import monthrange
from datetime import date, timedelta
from decimal import Decimal

from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models

from clientes.models import Cliente, Ciudad
from trabajadores.models import Trabajador


def _mover_mes(anio, mes, desplazamiento=1):
    indice = (anio * 12 + (mes - 1)) + desplazamiento
    return indice // 12, indice % 12 + 1


def _fecha_segura(anio, mes, dia):
    return date(anio, mes, min(max(int(dia or 1), 1), monthrange(anio, mes)[1]))


class Contrato(models.Model):
    TIPO_CHOICES = [
        ("semanal", "Semanal"),
        ("quincenal", "Quincenal"),
        ("mensual", "Mensual"),
        ("variable", "Variable"),
    ]

    FRECUENCIA_CHOICES = [
        ("1_semanal", "1 visita semanal"),
        ("2_semanales", "2 visitas semanales"),
        ("3_semanales", "3 visitas semanales"),
        ("quincenal", "Cada 15 días"),
        ("personalizado", "Personalizado"),
    ]

    # Los valores históricos se conservan en choices para que ningún contrato
    # existente pierda su configuración. La interfaz usa las listas *_ACTIVAS.
    FORMA_PAGO_CHOICES = [
        ("adelantado", "Mes Adelantado"),
        ("servicio_cumplido", "Mes Cumplido"),
        ("50_50", "Inicio 50% - 50% Final"),
        ("por_visita", "Por visita"),
        ("anual", "Anual"),
        # Compatibilidad histórica: no se ofrecen en contratos nuevos.
        ("quincenal", "Quincenal (anterior)"),
        ("fin_mensualidad", "Fin de la mensualidad (anterior)"),
        ("semestral_adelantado", "Anual · 2 pagos semestrales adelantados (anterior)"),
        ("personalizado", "Personalizado (anterior)"),
    ]
    FORMA_PAGO_CHOICES_ACTIVAS = [
        ("adelantado", "Mes Adelantado"),
        ("servicio_cumplido", "Mes Cumplido"),
        ("50_50", "Inicio 50% - 50% Final"),
        ("por_visita", "Por visita"),
        ("anual", "Anual"),
    ]

    PROGRAMACION_COBRO_CHOICES = [
        ("inicio_periodo", "Mismo día de inicio del periodo"),
        ("cierre_periodo", "Mismo día de cierre del periodo"),
        ("dia_fijo", "Día fijo mensual"),
        ("rango_dias", "Rango de días"),
        ("despues_cierre", "Días máximos después del cierre"),
        ("por_visita", "Por visita"),
        ("adelanto_mensualidades", "Adelanto de X mensualidades"),
        # Compatibilidad histórica/interna.
        ("dos_pagos", "Dos pagos mensuales (anterior)"),
        ("semestral_adelantado", "Pago semestral adelantado · 6 meses (anterior)"),
        ("personalizado", "Personalizado (anterior)"),
    ]
    PROGRAMACION_COBRO_CHOICES_ACTIVAS = [
        ("inicio_periodo", "Mismo día de inicio del periodo"),
        ("cierre_periodo", "Mismo día de cierre del periodo"),
        ("dia_fijo", "Día fijo mensual"),
        ("rango_dias", "Rango de días"),
        ("despues_cierre", "Días máximos después del cierre"),
        ("por_visita", "Por visita"),
        ("adelanto_mensualidades", "Adelanto de X mensualidades"),
    ]


    QUIMICOS_PROVEEDOR_CHOICES = [
        ("jvaqua", "JVAQUA"),
        ("cliente", "Cliente"),
    ]

    QUIMICOS_ALMACENAMIENTO_CHOICES = [
        ("trabajador", "Inventario del trabajador"),
        ("contrato", "Inventario del contrato (en sitio)"),
    ]

    MOMENTO_FACTURACION_CHOICES = [
        ("antes_inicio", "Antes de iniciar el periodo"),
        ("inicio_periodo", "Al iniciar el periodo"),
        ("cierre_periodo", "Al finalizar el periodo"),
        ("dia_fijo", "Día fijo del mes"),
        ("antes_cobro", "Días antes del cobro"),
        ("por_visita", "Por visita"),
        ("personalizado", "Personalizado"),
    ]

    IVA_PORCENTAJE = Decimal("15.00")

    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE, related_name="contratos")

    # Ubicación propia de la piscina/contrato. Los campos del cliente se conservan
    # temporalmente como compatibilidad, pero ya no son la fuente principal.
    ciudad_ref = models.ForeignKey(Ciudad, on_delete=models.SET_NULL, null=True, blank=True, related_name="contratos")
    ciudad = models.CharField(max_length=100, blank=True, default="")
    sector_urbanizacion = models.CharField(max_length=150, blank=True, default="")
    direccion = models.TextField(blank=True, default="")
    enlace_google_maps = models.URLField(max_length=500, blank=True, default="")
    latitud = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    longitud = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    tipo = models.CharField(max_length=20, choices=TIPO_CHOICES)
    frecuencia = models.CharField(max_length=30, choices=FRECUENCIA_CHOICES, blank=True, default="")
    frecuencia_personalizada = models.CharField(max_length=150, blank=True, default="")

    # Condición comercial. No contiene fechas.
    forma_pago = models.CharField(max_length=30, choices=FORMA_PAGO_CHOICES, blank=True, default="")
    forma_pago_personalizada = models.CharField(max_length=150, blank=True, default="")

    # Campo anterior conservado por compatibilidad. Se sincroniza con cobro_dia_1.
    dia_pago = models.PositiveSmallIntegerField(null=True, blank=True)

    # Periodo del servicio.
    periodo_dia_inicio = models.PositiveSmallIntegerField(
        default=1,
        validators=[MinValueValidator(1), MaxValueValidator(31)],
        help_text="Día en que inicia cada periodo mensual del servicio.",
    )

    # Programación independiente de cobros.
    programacion_cobro = models.CharField(
        max_length=30,
        choices=PROGRAMACION_COBRO_CHOICES,
        default="inicio_periodo",
    )
    cobro_mes_desfase = models.PositiveSmallIntegerField(
        default=0,
        validators=[MinValueValidator(0), MaxValueValidator(2)],
        help_text="0 = mes del inicio del periodo; 1 = mes siguiente; 2 = dos meses después.",
    )
    cobro_dia_1 = models.PositiveSmallIntegerField(null=True, blank=True, validators=[MinValueValidator(1), MaxValueValidator(31)])
    cobro_dia_2 = models.PositiveSmallIntegerField(null=True, blank=True, validators=[MinValueValidator(1), MaxValueValidator(31)])
    cobro_rango_desde = models.PositiveSmallIntegerField(null=True, blank=True, validators=[MinValueValidator(1), MaxValueValidator(31)])
    cobro_rango_hasta = models.PositiveSmallIntegerField(null=True, blank=True, validators=[MinValueValidator(1), MaxValueValidator(31)])
    cobro_dias_despues_cierre = models.PositiveSmallIntegerField(default=0)
    cobro_meses_adelantados = models.PositiveSmallIntegerField(
        default=1,
        validators=[MinValueValidator(1), MaxValueValidator(12)],
        help_text="Cantidad de mensualidades que se cobran juntas por adelantado.",
    )
    porcentaje_primer_pago = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("50.00"),
        validators=[MinValueValidator(Decimal("0.01")), MaxValueValidator(Decimal("99.99"))],
    )
    programacion_cobro_personalizada = models.CharField(max_length=200, blank=True, default="")

    # Facturación independiente del calendario de cobro.
    requiere_factura = models.BooleanField(default=False)
    momento_facturacion = models.CharField(
        max_length=30,
        choices=MOMENTO_FACTURACION_CHOICES,
        blank=True,
        default="",
    )
    facturacion_dia = models.PositiveSmallIntegerField(null=True, blank=True, validators=[MinValueValidator(1), MaxValueValidator(31)])
    facturacion_dias_antes = models.PositiveSmallIntegerField(default=0)
    notificar_facturacion = models.BooleanField(default=False)
    notificacion_factura_dias_antes = models.PositiveSmallIntegerField(default=1)
    observaciones_facturacion = models.TextField(blank=True, default="")

    precio_mensual = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="Valor base mensual del contrato antes de IVA.",
    )
    aplica_iva = models.BooleanField(
        default=False,
        help_text="Si aplica, se agrega automáticamente IVA del 15% al valor que paga el cliente.",
    )
    valor_tecnico_mensual = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    fecha_inicio = models.DateField()
    fecha_inicio_original = models.DateField(null=True, blank=True, db_index=True)

    # Vigencia contractual. Vacío = contrato indefinido.
    vigencia_meses = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(120)],
        help_text="Duración contractual en meses. Vacío significa vigencia indefinida.",
    )
    fecha_fin_contrato = models.DateField(
        null=True,
        blank=True,
        db_index=True,
        help_text="Último día vigente del ciclo contractual actual.",
    )
    aviso_vencimiento_dias = models.PositiveSmallIntegerField(
        default=30,
        validators=[MinValueValidator(0), MaxValueValidator(365)],
        help_text="Días de anticipación para advertir que el contrato está por vencer.",
    )
    tecnico_designado = models.ForeignKey(
        Trabajador,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="contratos_designados",
    )
    dias_visita = models.JSONField(default=list, blank=True)
    generacion_automatica = models.BooleanField(default=True)
    programado_hasta = models.DateField(null=True, blank=True)
    activo = models.BooleanField(default=True)
    MOTIVO_BAJA_CHOICES = [
        ("precio", "Precio"),
        ("mudanza_venta", "Cliente vendió o se mudó"),
        ("piscina_fuera_uso", "Piscina fuera de uso"),
        ("mala_experiencia", "Mala experiencia"),
        ("cambio_proveedor", "Cambio de proveedor"),
        ("mantenimiento_propio", "Cliente realizará mantenimiento propio"),
        ("morosidad", "Morosidad"),
        ("servicio_temporal", "Servicio temporal finalizado"),
        ("otro", "Otro"),
        ("no_especificado", "No especificado"),
    ]
    fecha_baja = models.DateField(null=True, blank=True, db_index=True)
    motivo_baja = models.CharField(max_length=30, choices=MOTIVO_BAJA_CHOICES, blank=True, default="")
    motivo_baja_detalle = models.CharField(max_length=250, blank=True, default="")

    # Gestión logística de químicos por contrato.
    quimicos_proveedor = models.CharField(
        max_length=20,
        choices=QUIMICOS_PROVEEDOR_CHOICES,
        default="jvaqua",
        help_text="Indica si los químicos son proporcionados por JVAQUA o por el cliente.",
    )
    quimicos_almacenamiento = models.CharField(
        max_length=20,
        choices=QUIMICOS_ALMACENAMIENTO_CHOICES,
        default="trabajador",
        blank=True,
        help_text="Cuando JVAQUA proporciona químicos, indica dónde se almacenan.",
    )
    HORARIO_VISITA_CHOICES = [
        ("libre", "Horario libre"),
        ("fijo", "Hora fija"),
        ("ventana", "Ventana horaria"),
    ]

    PRIORIDAD_VISITA_CHOICES = [
        ("normal", "Normal"),
        ("alta", "Alta"),
    ]

    tipo_horario_visita = models.CharField(
        max_length=20, choices=HORARIO_VISITA_CHOICES, default="libre",
        help_text="Restricción horaria usada únicamente para sugerir la ruta diaria al técnico.",
    )
    hora_visita_fija = models.TimeField(null=True, blank=True)
    ventana_visita_desde = models.TimeField(null=True, blank=True)
    ventana_visita_hasta = models.TimeField(null=True, blank=True)
    duracion_estimada_minutos = models.PositiveSmallIntegerField(
        default=30, validators=[MinValueValidator(10), MaxValueValidator(480)],
        help_text="Duración orientativa del mantenimiento para planificar la ruta.",
    )
    prioridad_visita = models.CharField(
        max_length=10, choices=PRIORIDAD_VISITA_CHOICES, default="normal"
    )

    responsable_reposicion = models.ForeignKey(
        Trabajador,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="contratos_reposicion",
        help_text="Responsable principal de reponer el inventario en sitio. Si se deja vacío, se usa el técnico designado.",
    )

    # Ficha técnica opcional de la piscina.
    piscina_largo_m = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    piscina_ancho_m = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    piscina_profundidad_min_m = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    piscina_profundidad_max_m = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    piscina_volumen_m3 = models.DecimalField(max_digits=9, decimal_places=2, null=True, blank=True)
    piscina_tipo = models.CharField(max_length=80, blank=True, default="")
    piscina_uso = models.CharField(max_length=80, blank=True, default="")
    piscina_filtracion = models.CharField(max_length=100, blank=True, default="")
    piscina_desinfeccion = models.CharField(max_length=100, blank=True, default="")
    piscina_observaciones = models.TextField(blank=True, default="")

    def calcular_fecha_fin_contrato(self):
        """Último día del ciclo de vigencia actual."""
        if not self.fecha_inicio or not self.vigencia_meses:
            return None
        anio, mes = _mover_mes(
            self.fecha_inicio.year,
            self.fecha_inicio.month,
            int(self.vigencia_meses),
        )
        siguiente_ciclo = _fecha_segura(anio, mes, self.fecha_inicio.day)
        return siguiente_ciclo - timedelta(days=1)

    @property
    def vigencia_definida(self):
        return bool(self.vigencia_meses and self.fecha_fin_contrato)

    @property
    def dias_para_vencer(self):
        if not self.fecha_fin_contrato:
            return None
        return (self.fecha_fin_contrato - date.today()).days

    @property
    def estado_vigencia(self):
        if not self.fecha_fin_contrato:
            return "indefinido"
        dias = self.dias_para_vencer
        if dias is not None and dias < 0:
            return "vencido"
        if dias is not None and dias <= int(self.aviso_vencimiento_dias or 30):
            return "por_vencer"
        return "vigente"

    @property
    def iva_mensual(self):
        base = Decimal(self.precio_mensual or 0)
        if not self.aplica_iva:
            return Decimal("0.00")
        return (base * self.IVA_PORCENTAJE / Decimal("100")).quantize(Decimal("0.01"))

    @property
    def precio_mensual_total(self):
        return (Decimal(self.precio_mensual or 0) + self.iva_mensual).quantize(Decimal("0.01"))

    def desglose_valor(self, valor_base):
        base = Decimal(valor_base or 0).quantize(Decimal("0.01"))
        impuesto = (
            (base * self.IVA_PORCENTAJE / Decimal("100")).quantize(Decimal("0.01"))
            if self.aplica_iva else Decimal("0.00")
        )
        return {
            "base": base,
            "impuesto": impuesto,
            "total": (base + impuesto).quantize(Decimal("0.01")),
        }

    def ingreso_mensual(self):
        """Ingreso operativo antes de impuestos; el IVA no se considera utilidad."""
        return Decimal(self.precio_mensual or 0).quantize(Decimal("0.01"))

    def frecuencia_completa(self):
        if self.frecuencia == "personalizado":
            return self.frecuencia_personalizada or "Personalizada"
        if self.frecuencia:
            return self.get_frecuencia_display()
        equivalencias = {"semanal": "Semanal", "quincenal": "Cada 15 días", "mensual": "Mensual", "variable": "Variable"}
        return equivalencias.get(self.tipo, self.tipo or "Sin definir")

    frecuencia_completa.short_description = "Frecuencia"

    def forma_pago_completa(self):
        if self.forma_pago == "personalizado":
            return self.forma_pago_personalizada or "Personalizada"
        return self.get_forma_pago_display() if self.forma_pago else "Sin definir"

    forma_pago_completa.short_description = "Forma de pago"

    def dias_visita_completos(self):
        nombres = {0: "Lunes", 1: "Martes", 2: "Miércoles", 3: "Jueves", 4: "Viernes", 5: "Sábado", 6: "Domingo"}
        dias = []
        for valor in self.dias_visita or []:
            try:
                numero = int(valor)
            except (TypeError, ValueError):
                continue
            if numero in nombres and numero not in dias:
                dias.append(numero)
        return ", ".join(nombres[dia] for dia in sorted(dias)) or "Sin definir"

    dias_visita_completos.short_description = "Días de visita"

    def periodo_servicio(self, anio, mes):
        inicio = _fecha_segura(anio, mes, self.periodo_dia_inicio or self.fecha_inicio.day)
        anio_fin, mes_fin = _mover_mes(anio, mes, 1)
        fin = _fecha_segura(anio_fin, mes_fin, self.periodo_dia_inicio or self.fecha_inicio.day)
        return inicio, fin

    def calendario_cobros(self, anio, mes):
        """Devuelve cuotas para el periodo indicado sin escribir en la base."""
        inicio, fin = self.periodo_servicio(anio, mes)

        # Un ciclo que empieza después del vencimiento contractual no puede
        # producir nuevos cobros. Lo ya emitido/pagado permanece como historial.
        if self.fecha_fin_contrato and inicio > self.fecha_fin_contrato:
            return []

        programacion = self.programacion_cobro or "inicio_periodo"
        destino_anio, destino_mes = _mover_mes(anio, mes, int(self.cobro_mes_desfase or 0))

        # Anticipos por bloques de mensualidades. El modo histórico semestral
        # se interpreta como bloques de 6 sin modificar el dato almacenado.
        if programacion in {"adelanto_mensualidades", "semestral_adelantado"}:
            if not self.fecha_inicio:
                return []

            meses_bloque = 6 if programacion == "semestral_adelantado" else int(self.cobro_meses_adelantados or 1)
            meses_bloque = min(max(meses_bloque, 1), 12)
            vigencia = int(self.vigencia_meses or (12 if self.forma_pago in {"anual", "semestral_adelantado"} else meses_bloque))
            diferencia_meses = ((int(anio) - self.fecha_inicio.year) * 12 + (int(mes) - self.fecha_inicio.month))
            if diferencia_meses < 0 or diferencia_meses >= vigencia or diferencia_meses % meses_bloque != 0:
                return []

            meses_cubiertos = min(meses_bloque, vigencia - diferencia_meses)
            cobro_anio, cobro_mes = _mover_mes(self.fecha_inicio.year, self.fecha_inicio.month, diferencia_meses)
            fecha_cobro = _fecha_segura(cobro_anio, cobro_mes, self.fecha_inicio.day)
            fin_anio, fin_mes = _mover_mes(cobro_anio, cobro_mes, meses_cubiertos)
            fin_bloque = _fecha_segura(fin_anio, fin_mes, self.fecha_inicio.day)
            valor_bloque = (Decimal(self.precio_mensual or 0) * Decimal(meses_cubiertos)).quantize(Decimal("0.01"))
            desglose = self.desglose_valor(valor_bloque)
            return [{
                "cuota_numero": 1, "total_cuotas": 1,
                "fecha_cobro_desde": fecha_cobro, "fecha_vencimiento": fecha_cobro,
                "valor": desglose["base"], "impuesto": desglose["impuesto"], "total": desglose["total"],
                "periodo_inicio": fecha_cobro, "periodo_fin": fin_bloque,
                "meses_adelantados": meses_cubiertos,
            }]

        if programacion == "por_visita":
            # Pago por visita: cada mantenimiento del ciclo origina una cuota.
            # La suma de todas las cuotas mantiene exactamente el precio mensual
            # contractual; la última absorbe cualquier centavo de redondeo.
            from mantenimientos.models import Mantenimiento

            visitas = list(
                Mantenimiento.objects.filter(
                    contrato=self,
                    fecha__gte=max(inicio, self.fecha_inicio),
                    fecha__lt=fin,
                )
                .order_by("fecha", "id")
                .values("id", "fecha")
            )
            if not visitas:
                return []

            total_visitas = len(visitas)
            precio = Decimal(self.precio_mensual or 0).quantize(Decimal("0.01"))
            valor_regular = (precio / Decimal(total_visitas)).quantize(Decimal("0.01"))
            acumulado = Decimal("0.00")
            cuotas = []

            for indice, visita in enumerate(visitas, start=1):
                if indice == total_visitas:
                    valor_base = (precio - acumulado).quantize(Decimal("0.01"))
                else:
                    valor_base = valor_regular
                    acumulado += valor_base

                desglose = self.desglose_valor(valor_base)
                fecha_visita = visita["fecha"]
                cuotas.append({
                    "cuota_numero": indice,
                    "total_cuotas": total_visitas,
                    "fecha_cobro_desde": fecha_visita,
                    "fecha_vencimiento": fecha_visita,
                    "valor": desglose["base"],
                    "impuesto": desglose["impuesto"],
                    "total": desglose["total"],
                    "periodo_inicio": inicio,
                    "periodo_fin": fin,
                    "mantenimiento_id": visita["id"],
                    "fecha_visita": fecha_visita,
                    "es_por_visita": True,
                })
            return cuotas

        if programacion == "inicio_periodo":
            fechas = [(inicio, inicio)]
        elif programacion == "cierre_periodo":
            fechas = [(fin, fin)]
        elif programacion == "dia_fijo":
            fecha = _fecha_segura(destino_anio, destino_mes, self.cobro_dia_1 or self.dia_pago or inicio.day)
            fechas = [(fecha, fecha)]
        elif programacion == "rango_dias":
            desde = _fecha_segura(destino_anio, destino_mes, self.cobro_rango_desde or 1)
            hasta = _fecha_segura(destino_anio, destino_mes, self.cobro_rango_hasta or self.cobro_rango_desde or 1)
            if hasta < desde:
                hasta = desde
            fechas = [(desde, hasta)]
        elif programacion == "dos_pagos":
            # La condición 50/50 actual usa inicio y cierre reales del periodo.
            # Los contratos históricos con "dos_pagos" conservan sus días guardados.
            if self.forma_pago == "50_50":
                fechas = [(inicio, inicio), (fin, fin)]
            else:
                f1 = _fecha_segura(destino_anio, destino_mes, self.cobro_dia_1 or 1)
                f2 = _fecha_segura(destino_anio, destino_mes, self.cobro_dia_2 or 15)
                if f2 < f1:
                    f1, f2 = f2, f1
                fechas = [(f1, f1), (f2, f2)]
        elif programacion == "despues_cierre":
            fecha = fin + timedelta(days=int(self.cobro_dias_despues_cierre or 0))
            fechas = [(fecha, fecha)]
        else:
            fecha = _fecha_segura(destino_anio, destino_mes, self.cobro_dia_1 or inicio.day)
            fechas = [(fecha, fecha)]

        if len(fechas) == 2:
            porcentaje_1 = Decimal(self.porcentaje_primer_pago or Decimal("50.00"))
            valor_1 = (self.precio_mensual * porcentaje_1 / Decimal("100")).quantize(Decimal("0.01"))
            valores = [valor_1, self.precio_mensual - valor_1]
        else:
            valores = [self.precio_mensual]

        cuotas = []
        for indice, ventana in enumerate(fechas, start=1):
            desglose = self.desglose_valor(valores[indice - 1])
            cuotas.append({
                "cuota_numero": indice,
                "total_cuotas": len(fechas),
                "fecha_cobro_desde": ventana[0],
                "fecha_vencimiento": ventana[1],
                # "valor" permanece como base por compatibilidad con promociones.
                "valor": desglose["base"],
                "impuesto": desglose["impuesto"],
                "total": desglose["total"],
                "periodo_inicio": inicio,
                "periodo_fin": fin,
            })
        return cuotas

    def fecha_programada_facturacion(self, anio, mes):
        """
        Fecha interna para recordar la emisión de la factura externa.

        Debe ser tolerante a contratos históricos o configuraciones comerciales
        incompletas: un contrato antiguo nunca debe tumbar todo el módulo de
        Facturación Externa.
        """
        if not self.requiere_factura:
            return None

        inicio, fin = self.periodo_servicio(anio, mes)
        calendario = self.calendario_cobros(anio, mes)

        # En modalidad semestral solo hay dos eventos reales de cobro/facturación
        # durante el año. Los demás meses no deben generar alertas de factura.
        if self.programacion_cobro == "semestral_adelantado":
            if not calendario:
                return None
            inicio = calendario[0]["periodo_inicio"]
            fin = calendario[0]["periodo_fin"]

        primer_cobro = (
            calendario[0].get("fecha_cobro_desde")
            if calendario
            else None
        )
        # Respaldo seguro para contratos históricos.
        primer_cobro = primer_cobro or fin

        momento = self.momento_facturacion or "antes_cobro"
        dias_antes = int(self.facturacion_dias_antes or 0)

        # En facturación por visita cada cuota usa su propia fecha en Cartera
        # y en Facturación Externa. Este método devuelve la primera solo como
        # referencia compatible para vistas/resúmenes antiguos.
        if momento == "por_visita":
            return primer_cobro if calendario else None

        if momento == "antes_inicio":
            return inicio - timedelta(days=dias_antes)
        if momento == "inicio_periodo":
            return inicio
        if momento == "cierre_periodo":
            return fin
        if momento == "dia_fijo":
            return _fecha_segura(
                primer_cobro.year,
                primer_cobro.month,
                self.facturacion_dia or primer_cobro.day,
            )
        if momento == "antes_cobro":
            return primer_cobro - timedelta(days=dias_antes)

        return _fecha_segura(
            primer_cobro.year,
            primer_cobro.month,
            self.facturacion_dia or primer_cobro.day,
        )

    def sincronizar_tipo_compatibilidad(self):
        equivalencias = {"1_semanal": "semanal", "2_semanales": "semanal", "3_semanales": "semanal", "quincenal": "quincenal", "personalizado": "variable"}
        if self.frecuencia in equivalencias:
            self.tipo = equivalencias[self.frecuencia]

    def save(self, *args, **kwargs):
        if not self.fecha_inicio_original and self.fecha_inicio:
            self.fecha_inicio_original = self.fecha_inicio

        # La modalidad semestral adelantada representa un compromiso anual.
        # Si se crea sin vigencia explícita, se establece automáticamente en 12 meses.
        if self.programacion_cobro == "semestral_adelantado" and not self.vigencia_meses:
            self.vigencia_meses = 12
        if self.forma_pago == "anual":
            self.vigencia_meses = 12

        if self.vigencia_meses and self.fecha_inicio:
            self.fecha_fin_contrato = self.calcular_fecha_fin_contrato()
        else:
            self.fecha_fin_contrato = None
        # La fecha de inicio es la única fuente del día de corte del periodo.
        # Evita configuraciones contradictorias entre "fecha de inicio" y "día de periodo".
        if self.fecha_inicio:
            self.periodo_dia_inicio = self.fecha_inicio.day
        self.ciudad = (self.ciudad or "").strip()
        self.sector_urbanizacion = (self.sector_urbanizacion or "").strip()
        self.direccion = (self.direccion or "").strip()
        self.enlace_google_maps = (self.enlace_google_maps or "").strip()
        if self.ciudad_ref_id:
            self.ciudad = self.ciudad_ref.nombre
        elif self.ciudad:
            ciudad_obj = Ciudad.objects.filter(nombre__iexact=self.ciudad).first()
            if ciudad_obj:
                self.ciudad_ref = ciudad_obj
                self.ciudad = ciudad_obj.nombre
        self.frecuencia_personalizada = (self.frecuencia_personalizada or "").strip()
        self.forma_pago_personalizada = (self.forma_pago_personalizada or "").strip()

        # Una condición "Por visita" no puede quedar combinada con una fecha
        # mensual. Cartera y facturación siguen automáticamente las visitas.
        if self.forma_pago == "por_visita":
            self.programacion_cobro = "por_visita"
            self.cobro_mes_desfase = 0
            self.cobro_dia_1 = None
            self.cobro_dia_2 = None
            self.cobro_rango_desde = None
            self.cobro_rango_hasta = None
            self.cobro_dias_despues_cierre = 0
            if self.requiere_factura:
                self.momento_facturacion = "por_visita"
                self.facturacion_dia = None
                self.facturacion_dias_antes = 0

        self.programacion_cobro_personalizada = (self.programacion_cobro_personalizada or "").strip()
        self.observaciones_facturacion = (self.observaciones_facturacion or "").strip()
        if self.quimicos_proveedor == "cliente":
            self.quimicos_almacenamiento = ""
            self.responsable_reposicion = None
        elif self.quimicos_almacenamiento not in {"trabajador", "contrato"}:
            self.quimicos_almacenamiento = "trabajador"
        if self.frecuencia != "personalizado":
            self.frecuencia_personalizada = ""
        if self.forma_pago != "personalizado":
            self.forma_pago_personalizada = ""
        if self.programacion_cobro != "personalizado":
            self.programacion_cobro_personalizada = ""
        if self.programacion_cobro == "dia_fijo":
            self.dia_pago = self.cobro_dia_1
        else:
            self.dia_pago = None
        if not self.requiere_factura:
            self.momento_facturacion = ""
            self.facturacion_dia = None
            self.notificar_facturacion = False
            self.observaciones_facturacion = ""
        else:
            # Toda factura requerida genera aviso interno. La emisión se realiza
            # externamente y luego se marca como realizada dentro de JVAQUA.
            self.notificar_facturacion = True
        self.sincronizar_tipo_compatibilidad()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.cliente} - {self.frecuencia_completa()}"

    class Meta:
        verbose_name = "Contrato"
        verbose_name_plural = "Contratos"
        ordering = ["-activo", "cliente__nombre", "id"]




class RenovacionContrato(models.Model):
    contrato = models.ForeignKey(
        Contrato,
        on_delete=models.CASCADE,
        related_name="renovaciones",
    )
    registrada_por = models.ForeignKey(
        "auth.User",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="renovaciones_contrato_registradas",
    )
    fecha_renovacion = models.DateField(default=date.today, db_index=True)
    inicio_anterior = models.DateField()
    fin_anterior = models.DateField(null=True, blank=True)
    nuevo_inicio = models.DateField()
    nuevo_fin = models.DateField(null=True, blank=True)
    vigencia_meses = models.PositiveSmallIntegerField(null=True, blank=True)
    observaciones = models.CharField(max_length=250, blank=True, default="")
    creada_en = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-fecha_renovacion", "-id"]
        verbose_name = "Renovación de contrato"
        verbose_name_plural = "Renovaciones de contratos"

    def __str__(self):
        return f"{self.contrato} · renovación {self.fecha_renovacion:%d/%m/%Y}"


class ReactivacionContrato(models.Model):
    contrato = models.ForeignKey(Contrato, on_delete=models.CASCADE, related_name="reactivaciones")
    fecha_reactivacion = models.DateField(db_index=True)
    registrada_en = models.DateTimeField(auto_now_add=True)
    registrada_por = models.ForeignKey("auth.User", on_delete=models.SET_NULL, null=True, blank=True)

    # Referencia de la baja que dio origen a esta recuperación.
    fecha_baja_anterior = models.DateField(null=True, blank=True)
    motivo_baja_anterior = models.CharField(max_length=30, blank=True, default="")

    # Condiciones vigentes al momento de recuperar el contrato.
    fecha_inicio_anterior = models.DateField(null=True, blank=True)
    fecha_inicio = models.DateField()
    frecuencia = models.CharField(max_length=30, blank=True, default="")
    frecuencia_personalizada = models.CharField(max_length=150, blank=True, default="")
    dias_visita = models.JSONField(default=list, blank=True)
    tecnico_designado = models.ForeignKey(
        Trabajador, on_delete=models.SET_NULL, null=True, blank=True, related_name="reactivaciones_contrato"
    )
    forma_pago = models.CharField(max_length=30, blank=True, default="")
    forma_pago_personalizada = models.CharField(max_length=150, blank=True, default="")
    periodo_dia_inicio = models.PositiveSmallIntegerField(default=1)
    programacion_cobro = models.CharField(max_length=30, blank=True, default="")
    cobro_mes_desfase = models.PositiveSmallIntegerField(default=0)
    cobro_dia_1 = models.PositiveSmallIntegerField(null=True, blank=True)
    cobro_dia_2 = models.PositiveSmallIntegerField(null=True, blank=True)
    cobro_rango_desde = models.PositiveSmallIntegerField(null=True, blank=True)
    cobro_rango_hasta = models.PositiveSmallIntegerField(null=True, blank=True)
    cobro_dias_despues_cierre = models.PositiveSmallIntegerField(default=0)
    cobro_meses_adelantados = models.PositiveSmallIntegerField(
        default=1,
        validators=[MinValueValidator(1), MaxValueValidator(12)],
        help_text="Cantidad de mensualidades que se cobran juntas por adelantado.",
    )
    porcentaje_primer_pago = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("50.00"))
    programacion_cobro_personalizada = models.CharField(max_length=200, blank=True, default="")
    precio_mensual = models.DecimalField(max_digits=10, decimal_places=2)
    valor_tecnico_mensual = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def __str__(self):
        return f"Reactivación #{self.pk} · {self.contrato} · {self.fecha_reactivacion:%d/%m/%Y}"

    class Meta:
        verbose_name = "Reactivación de contrato"
        verbose_name_plural = "Reactivaciones de contratos"
        ordering = ["-fecha_reactivacion", "-registrada_en", "-id"]


class EquipamientoContrato(models.Model):
    contrato = models.ForeignKey(Contrato, on_delete=models.CASCADE, related_name="equipamientos")
    nombre = models.CharField(max_length=150)
    costo_jvaqua = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    valor_mensual_adicional = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    fecha_entrega = models.DateField(null=True, blank=True)
    estado = models.CharField(max_length=80, blank=True, default="")
    debe_devolverse = models.BooleanField(default=True)
    activo = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.nombre} · {self.contrato}"


class CotizacionMantenimiento(models.Model):
    FRECUENCIA_CHOICES = Contrato.FRECUENCIA_CHOICES
    creada_en = models.DateTimeField(auto_now_add=True)
    creada_por = models.ForeignKey("auth.User", on_delete=models.SET_NULL, null=True, blank=True)
    ciudad = models.ForeignKey("clientes.Ciudad", on_delete=models.SET_NULL, null=True, blank=True)
    cliente_referencia = models.ForeignKey("clientes.Cliente", on_delete=models.SET_NULL, null=True, blank=True)
    nombre_referencia = models.CharField(max_length=150, blank=True, default="")
    largo_m = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    ancho_m = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    profundidad_m = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    volumen_m3 = models.DecimalField(max_digits=9, decimal_places=2, null=True, blank=True)
    frecuencia = models.CharField(max_length=30, choices=FRECUENCIA_CHOICES)
    quimicos_incluidos = models.BooleanField(default=True)
    equipamiento_mensual = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    ajuste_especial_mensual = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    observaciones = models.TextField(blank=True, default="")
    contratos_similares = models.PositiveIntegerField(default=0)
    promedio_mercado_interno = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    costo_quimico_estimado = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    pago_tecnico_minimo = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    pago_tecnico_recomendado = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    pago_tecnico_maximo = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    precio_minimo = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    precio_recomendado = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    precio_objetivo = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    utilidad_estimada = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    margen_estimado = models.DecimalField(max_digits=6, decimal_places=2, default=0)

    def __str__(self):
        return f"Cotización #{self.pk or 'nueva'} · {self.nombre_referencia or self.ciudad or 'Piscina'}"
